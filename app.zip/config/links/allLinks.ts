export const STORE_URLS = {
  ENCRIPTADOS_ANDROID_URL:
    "https://play.google.com/store/apps/details?id=io.encriptados.app",
  ENCRIPTADOS_IOS_URL: "https://apps.apple.com/us/app/encriptados/id6661017242",
  FANTASMA_ANDROID_URL:
    "https://play.google.com/store/apps/details?id=io.encriptados.ghost.app",
  FANTASMA_IOS_URL: "https://apps.apple.com/co/app/fantasma-sim/id6596728440",
};
