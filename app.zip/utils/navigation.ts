export let hasAlreadyRedirected = false;

export const setHasAlreadyRedirected = (value: boolean) => {
  hasAlreadyRedirected = value;
};
