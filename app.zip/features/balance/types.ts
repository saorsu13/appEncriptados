export interface BalanceRequest {
  id: number | undefined;
  currencyCode: string | undefined;
  country: string | undefined;
}
