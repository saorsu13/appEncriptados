export interface Sim {
    simName: string;
    idSim: string;
    code: number;
    iccid: string;
}