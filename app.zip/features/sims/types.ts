export interface Sim {
    simName: string;
    name?: string;
    idSim: string;
    code: number;
    iccid: string;
    provider: string;
}