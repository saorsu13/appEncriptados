export const HOME_TAB_ROUTES = {
  HOME_TAB_INDEX: "/home-tab",
};
