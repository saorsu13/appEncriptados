export const PRODUCT_TAB_ROUTES = {
  PRODUCT_TAB_INDEX: "/products-tab",
  INFO_PRODUCT: "/aboutproduct/",
};
