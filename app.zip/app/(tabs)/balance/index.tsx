import { View, ScrollView, BackHandler, Platform } from "react-native";
import { useRouter, Stack } from "expo-router"; 
import { useEffect } from "react";
import { useTheme } from "@shopify/restyle";
import { ThemeCustom } from "@/config/theme2";
import { balanceStyles } from "./balanceStyles";

import HeaderEncrypted from "@/components/molecules/HeaderEncrypted/HeaderEncrypted";
import SimCurrencySelector from "@/components/molecules/SimCurrencySelector/SimCurrencySelector";
import CurrentBalance from "@/components/molecules/CurrentBalance/CurrentBalance";
import DataBalanceCard from "@/components/molecules/DataBalanceCard/DataBalanceCard";
import TopUpCard from "@/components/molecules/TopUpCard/TopUpCard";
import DeleteSimButton from "@/components/molecules/DeleteSimButton/DeleteSimButton";

const BalanceScreen = () => {
  const router = useRouter();
  const { colors } = useTheme<ThemeCustom>();

  useEffect(() => {
    if (Platform.OS === "android") {
      const handleBack = () => {
        router.back(); // ✅ Retrocede a la pantalla anterior en Android
        return true;
      };
      const backHandler = BackHandler.addEventListener("hardwareBackPress", handleBack);
      return () => backHandler.remove();
    }
  }, [router]);

  return (
    <>
      {/* ✅ Habilitar el header en iOS para permitir gestos de swipe-back */}
      <Stack.Screen
        options={{
          headerShown: true, // ✅ Necesario para swipe-back en iOS
          headerTitle: "", 
          headerTransparent: true, 
          headerBackTitleVisible: false,
          headerTintColor: "white", 
          gestureEnabled: true, // 🔥 Asegurar que el gesto esté activo
        }}
      />

      <View style={{ ...balanceStyles.container, backgroundColor: colors.background }}>
        {/* 🔹 Header con botón de configuración */}
        <HeaderEncrypted settingsLink="balance/settings" />

        <ScrollView contentContainerStyle={balanceStyles.content}>
          {/* 🔹 Selector de SIM y Divisa */}
          <SimCurrencySelector />

          {/* 🔹 Línea separadora gris */}
          <View style={balanceStyles.separator} />

          {/* 🔹 Saldo actual */}
          <CurrentBalance />

          {/* 🔹 Tarjeta de datos móviles */}
          <DataBalanceCard />

          {/* 🔹 Tarjeta de recarga */}
          <TopUpCard />

          {/* 🔹 Botón para borrar SIM con mayor espacio */}
          <DeleteSimButton onPress={() => console.log("SIM borrada")} />
        </ScrollView>
      </View>
    </>
  );
};

export default BalanceScreen;
