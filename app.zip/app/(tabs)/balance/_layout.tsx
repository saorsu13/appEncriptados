import { ThemeCustom } from "@/config/theme2";
import { useTheme } from "@shopify/restyle";
import { Stack } from "expo-router";

export default function BalanceLayout() {
  const { colors } = useTheme<ThemeCustom>();

  return (
    <Stack
      screenOptions={{
        headerShown: true, // ✅ Permitir que iOS muestre la barra de navegación
        gestureEnabled: true, // ✅ Habilita el swipe-back en iOS
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen 
        name="index"
        options={{ 
          headerShown: true, // 🔥 Asegúrate de que el header no está oculto
          gestureEnabled: true, // 🔥 Permitir swipe-back
          headerTitle: "", // 🔹 Oculta el título para diseño limpio
          headerTransparent: true, // 🔹 Hace el header transparente
          headerBackTitleVisible: false, // 🔹 Oculta el texto "Back"
          headerTintColor: "white", // 🔹 Color del botón de retroceso
        }}
      />
    </Stack>
  );
}
