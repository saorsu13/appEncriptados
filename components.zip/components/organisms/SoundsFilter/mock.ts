export const mockData = [
  {
    value: "0",
    label: "Filter 1",
  },
  {
    value: "1",
    label: "Filter 2",
  },
  {
    value: "2",
    label: "Filter 3",
  },
  {
    value: "3",
    label: "Filter 4",
  },
  {
    value: "4",
    label: "Filter 5",
  },
  {
    value: "5",
    label: "Filter 6",
  },
  {
    value: "6",
    label: "Filter 7",
  }
];
